# License Plate Detector > 2025-04-15 3:09pm
https://universe.roboflow.com/mleng/license-plate-detector-ogxxg-ks475

Provided by a Roboflow user
License: CC BY 4.0

